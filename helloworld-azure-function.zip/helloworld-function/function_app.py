import azure.functions as func
import logging

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)


@app.route(route="HelloWorld", methods=["GET", "POST"])
def HelloWorld(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("HelloWorld function processed a request.")

    name = req.params.get("name")
    if not name:
        try:
            req_body = req.get_json()
        except ValueError:
            req_body = None
        if req_body:
            name = req_body.get("name")

    if name:
        message = f"Hello, {name}!"
    else:
        message = "Hello, World!"

    return func.HttpResponse(message, status_code=200)
